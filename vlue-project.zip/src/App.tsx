import { useState, useEffect } from 'react';
import { supabase } from './lib/supabase';

export default function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
    });
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <main className="max-w-7xl mx-auto px-4 py-20">
        <h1 className="text-4xl font-bold text-white mb-4">VLUE</h1>
        <p className="text-gray-300">보이스피싱 방지 플랫폼</p>
      </main>
    </div>
  );
}